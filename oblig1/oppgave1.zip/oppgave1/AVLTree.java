public class AVLTree extends BinarySearchTree {
    
    AVLTree() {
        super();
    }

    public int height(Node v) { //returnerer treets høyde
        if (v == null) {
            return -1;
        }
        return v.height;
    }

    public void setHeight(Node v) { //setter høyde
        if (v != null) {
            v.height = 1 + Math.max(height(v.left), height(v.right));
        }
    }

    public Node leftRotate(Node z) { //roterer til venstre
        Node y = z.right;
        Node t1 = y.left;
        y.left = z;
        z.right = t1;
        setHeight(z);
        setHeight(y);
        return y;
    }

    public Node rightRotate(Node z) { //roterer til høyre
        Node y = z.left;
        Node t1 = y.right;
        y.right = z;
        z.left = t1;
        setHeight(z);
        setHeight(y);
        return y;
    }

    public int balanceFactor(Node v) { //returnerer balansefaktor 
        if (v == null) {
            return 0;
        }
        return height(v.left) - height(v.right);
    }

    public Node balance(Node v) { //balanserer treet
        if (balanceFactor(v) < -1) {
            if (balanceFactor(v.right) > 0) {
                v.right = rightRotate(v.right);
            }
            return leftRotate(v);
        }
        else if (balanceFactor(v) > 1) {
            if (balanceFactor(v.left) < 0) {
                v.left = leftRotate(v.left);
            }
            return rightRotate(v);
        }
        return v;
    }

    @Override
    public Node insert(Node v, int x) { //setter inn node med element og balanserer
        v = super.insert(v, x);
        setHeight(v);
        return balance(v);
    }

    @Override
    public Node remove(Node v, int x) { //slett node med element og balanserer
        v = super.remove(v, x);
        setHeight(v);
        return balance(v);
    }

}

