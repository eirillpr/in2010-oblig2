import java.util.Scanner;

class BinarySearchTree {
    Node root;
    int operations;
    int size = 0;

    public BinarySearchTree() {
        Scanner sc = new Scanner(System.in);
        System.out.println("How many operations? ");
        this.operations = sc.nextInt();
        sc.nextLine();
        for (int i = 0; i < operations; i++) {
            String operation = sc.nextLine();
            String[] operationArray = operation.split(" ");
            if (operationArray[0].equals("insert")) {
                int x = Integer.valueOf(operationArray[1]);
                root = insert(root, x);
            }
            else if (operationArray[0].equals("contains")) {
                int x = Integer.valueOf(operationArray[1]);
                System.out.println(contains(root, x));
            }
            else if (operationArray[0].equals("remove")) {
                int x = Integer.valueOf(operationArray[1]);
                root = remove(root, x);
            }
            else if (operationArray[0].equals("size")) {
                System.out.println(size(root));
            }
            else {
                System.out.println("Operation not supported");
            }
            
        }
        sc.close();
    }

    public Node insert(Node v, int x) { //sett inn node i bst 
        if (v == null) {
            size++;
            v = new Node(x);
        }
        else if (x < v.element) {
            v.left = insert(v.left, x);
        }
        else if (x > v.element) {
            v.right = insert(v.right, x);
        }
        return v;
    }

    public boolean contains(Node v, int x) { //sjekk om bst inneholder node med gitt element
        if (v == null) {
            return false;
        }
        else if (v.element == x) {
            return true;
        }
        else if (x < v.element) {
            return contains(v.left, x);
        }
        else {
            return contains(v.right, x);
        }
    }

    public Node findMin(Node v) { //finn minste element i node for et gitt tre
        if (v == null) {
            return null;
        }
        if (v.left != null) {
            return findMin(v.left);
        }
        else {
            return v;
        }
    }

    public Node remove(Node v, int x) { //slett node med element og omstrukturer bst om nødvendig
        if (v == null) {
            return null;
        }
        else if (x < v.element) {
            v.left = remove(v.left, x);
            return v;
        }
        else if (x > v.element) {
            v.right = remove(v.right, x);
            return v;
        }
        else {
            if (v.left == null && v.right == null) {
                size--;
                return null;
            }
            if (v.left == null) {
                size--;
                return v.right;
            }
            if (v.right == null) {
                size--;
                return v.left;
            }
            else {
                Node u = findMin(v.right);
                v.element = u.element;
                v.right = remove(v.right, u.element);
                return v;
            }
        }
    }

    public int size(Node v) { //antall noder i bst
        return size;
    }
}