public class MainAVL {
    public static void main(String[] args) {
        AVLTree avl = new AVLTree();
    }
}
