public class MainBST {
    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
    }
}
