public class Node {
    public int element;
    Node left, right;
    int height = 0;

    Node(int element) {
        this.element = element;
        left = right = null;
    }

    public void setLeft(Node node) {
        this.left = node;
    }

    public void setRight(Node node) {
        this.right = node;
    }
}
